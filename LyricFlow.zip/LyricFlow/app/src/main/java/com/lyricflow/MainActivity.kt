package com.lyricflow

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Theme(val name: String, val top: Color, val bottom: Color, val text: Color)

val themes = listOf(
    Theme("Midnight", Color(0xFF1B1F3B), Color(0xFF0A0B14), Color.White),
    Theme("Sunset", Color(0xFFFF7E5F), Color(0xFF6A1B9A), Color.White),
    Theme("Forest", Color(0xFF2E7D32), Color(0xFF07140A), Color.White),
    Theme("Ocean", Color(0xFF0288D1), Color(0xFF021A2E), Color.White),
    Theme("AMOLED", Color.Black, Color.Black, Color.White),
    Theme("Paper", Color(0xFFFFF8E7), Color(0xFFEADFC6), Color(0xFF222222)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lf", MODE_PRIVATE)
        setContent {
            var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            var translate by remember { mutableStateOf(false) }
            var listening by remember { mutableStateOf(false) }
            var lines by remember { mutableStateOf(emptyList<Line>()) }
            var tr by remember { mutableStateOf<List<String>?>(null) }
            var pos by remember { mutableLongStateOf(0L) }
            val track by Now.track.collectAsState()
            val scope = rememberCoroutineScope()
            val th = themes[themeIdx]
            val enabled = NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName)
            val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) scope.launch {
                    listening = true
                    Recognizer.listen(cacheDir)?.let { (t, a) ->
                        Now.track.value = Track(t, a, 0, true, SystemClock.elapsedRealtime())
                    }
                    listening = false
                }
            }

            LaunchedEffect(track?.title, track?.artist) {
                lines = emptyList(); tr = null
                track?.let { lines = Lrclib.fetch(it.title, it.artist) }
            }
            LaunchedEffect(translate, lines) {
                tr = if (translate && lines.isNotEmpty()) runCatching { Translator.translate(lines) }.getOrNull() else null
            }
            LaunchedEffect(track) {
                while (true) {
                    track?.let { pos = if (it.playing) it.posMs + SystemClock.elapsedRealtime() - it.stamp else it.posMs }
                    delay(100)
                }
            }
            val active = lines.indexOfLast { it.ms <= pos }.coerceAtLeast(0)
            val list = rememberLazyListState()
            LaunchedEffect(active) { if (lines.isNotEmpty()) list.animateScrollToItem(active, -300) }

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.top, th.bottom)))) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
                    Text(track?.title ?: "Nothing playing", color = th.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(track?.artist ?: "Play a song in Spotify", color = th.text.copy(0.6f), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    when {
                        !enabled -> Text("Tap here to allow Now Playing access", color = th.text, fontSize = 18.sp,
                            modifier = Modifier.clickable { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.padding(vertical = 24.dp))
                        track != null && lines.isEmpty() -> Text("No synced lyrics found", color = th.text.copy(0.6f), modifier = Modifier.padding(24.dp))
                        else -> LazyColumn(Modifier.weight(1f), state = list) {
                            itemsIndexed(lines) { i, l ->
                                val a by animateFloatAsState(if (i == active) 1f else 0.35f, label = "a")
                                Column(Modifier.padding(vertical = 10.dp).alpha(a)) {
                                    Text(l.text.ifBlank { "♪" }, color = th.text, fontSize = if (i == active) 30.sp else 24.sp, fontWeight = FontWeight.Bold)
                                    tr?.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { Text(it, color = th.text.copy(0.7f), fontSize = 16.sp) }
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        Chip("Theme: ${th.name}", th) { themeIdx = (themeIdx + 1) % themes.size; prefs.edit().putInt("theme", themeIdx).apply() }
                        Chip(if (translate) "Translate: on" else "Translate: off", th) { translate = !translate }
                        Chip(if (listening) "Listening…" else "Identify", th) { if (!listening) micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                    }
                }
            }
        }
    }
}

@Composable
fun Chip(label: String, th: Theme, onClick: () -> Unit) {
    Text(label, color = th.text, fontSize = 13.sp, modifier = Modifier
        .background(th.text.copy(0.15f), androidx.compose.foundation.shape.RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp))
}
