package com.lyricflow

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.PlaybackState
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

data class Track(val title: String, val artist: String, val posMs: Long, val playing: Boolean, val stamp: Long)

object Now { val track = MutableStateFlow<Track?>(null) }

/** Reads what Spotify (or any player) is playing from its media session. Instant and free. */
class NowPlayingService : NotificationListenerService() {
    private var controller: MediaController? = null
    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
    }
    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, NowPlayingService::class.java)
        msm.addOnActiveSessionsChangedListener(sessions, cn)
        pick(msm.getActiveSessions(cn))
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(cb)
        controller = list?.firstOrNull { it.packageName == "com.spotify.music" } ?: list?.firstOrNull()
        controller?.registerCallback(cb)
        push()
    }

    private fun push() {
        val c = controller ?: return
        val m = c.metadata ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val s = c.playbackState
        Now.track.value = Track(title, artist, s?.position ?: 0L,
            s?.state == PlaybackState.STATE_PLAYING, SystemClock.elapsedRealtime())
    }
}
