package com.lyricflow

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

data class Track(
    val title: String, val artist: String, val posMs: Long, val playing: Boolean, val stamp: Long,
    val durMs: Long = 0L, val art: Bitmap? = null, val album: String = "", val meta: String = ""
)

object Now { val track = MutableStateFlow<Track?>(null) }

class NowPlayingService : NotificationListenerService() {
    private var controller: MediaController? = null
    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
    }
    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, NowPlayingService::class.java)
        msm.addOnActiveSessionsChangedListener(sessions, cn)
        pick(msm.getActiveSessions(cn))
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(cb)
        controller = list?.firstOrNull { it.packageName == "com.spotify.music" } ?: list?.firstOrNull()
        controller?.registerCallback(cb)
        push()
    }

    private fun push() {
        val c = controller ?: return
        val m = c.metadata ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val s = c.playbackState
        // position is valid as of lastPositionUpdateTime, not "now"
        val stamp = s?.lastPositionUpdateTime?.takeIf { it > 0 } ?: SystemClock.elapsedRealtime()
        Now.track.value = Track(title, artist, s?.position ?: 0L, s?.state == PlaybackState.STATE_PLAYING,
            stamp, m.getLong(MediaMetadata.METADATA_KEY_DURATION), art)
    }
}
