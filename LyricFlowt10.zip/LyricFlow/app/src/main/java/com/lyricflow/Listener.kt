package com.lyricflow

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.math.abs

/** Free on-device speech recognition (Vosk). Hears the vocals and reports each word with the time it was heard. */
class LyricListener(private val ctx: Context) {
    var onWords: (List<Pair<String, Long>>) -> Unit = {}
    private var model: Model? = null
    private var svc: SpeechService? = null
    private val name = "vosk-model-small-en-us-0.15"

    suspend fun ensureModel(): Model? = withContext(Dispatchers.IO) {
        model?.let { return@withContext it }
        val dir = File(ctx.filesDir, name)
        val done = File(dir, ".done")
        try {
            if (!done.exists()) {
                val root = ctx.filesDir.canonicalPath
                ZipInputStream(URL("https://alphacephei.com/vosk/models/$name.zip").openStream().buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val f = File(ctx.filesDir, e.name)
                        if (f.canonicalPath.startsWith(root)) {
                            if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                        }
                        e = z.nextEntry
                    }
                }
                done.writeText("ok")
            }
            Model(dir.path).also { model = it }
        } catch (e: Exception) { null }
    }

    fun start(m: Model) {
        stop()
        try {
            val rec = org.vosk.Recognizer(m, 16000.0f)
            rec.setWords(true)
            val s = SpeechService(rec, 16000.0f)
            val t0 = SystemClock.elapsedRealtime()
            s.startListening(object : RecognitionListener {
                override fun onResult(h: String?) = handle(h, t0)
                override fun onFinalResult(h: String?) = handle(h, t0)
                override fun onPartialResult(h: String?) {}
                override fun onError(e: Exception?) {}
                override fun onTimeout() {}
            })
            svc = s
        } catch (e: Exception) { svc = null }
    }

    fun stop() { svc?.stop(); svc?.shutdown(); svc = null }

    private fun handle(h: String?, t0: Long) {
        val arr = try { JSONObject(h ?: return).optJSONArray("result") } catch (e: Exception) { null } ?: return
        val out = ArrayList<Pair<String, Long>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(o.getString("word") to t0 + (o.getDouble("start") * 1000).toLong())
        }
        if (out.isNotEmpty()) onWords(out)
    }
}

class Fit(val stamp: Long, val votes: Int)

/** Matches heard words to lyric words; each match votes for when the song started. Only trusted when votes are strong and unambiguous. */
class Aligner(lines: List<Line>) {
    private class W(val w: String, val t: Long)
    private val lw: List<W>
    private val stop = setOf("the", "and", "you", "your", "for", "that", "this", "with", "are", "was", "but", "not", "all",
        "can", "its", "just", "like", "oh", "yeah", "ooh", "got", "get", "let", "when", "what", "she", "him", "her", "his",
        "they", "them", "have", "has", "had", "been", "will", "would", "from", "out", "one", "way", "too", "now", "how",
        "who", "why", "than", "then", "there", "here", "ill", "dont", "cant", "wont", "baby", "gonna", "wanna")

    init {
        val out = ArrayList<W>()
        for ((i, l) in lines.withIndex()) {
            for ((w, a, _) in wordTimes(l, lines.getOrNull(i + 1)?.ms ?: (l.ms + 4000))) {
                val n = norm(w)
                if (usable(n)) out.add(W(n, a))
            }
        }
        lw = out
    }

    private fun usable(w: String) = w.length >= 3 && w !in stop

    fun estimate(words: List<Pair<String, Long>>, stamp: Long, window: Long, need: Int): Fit? {
        val offs = ArrayList<Pair<Long, String>>()
        for ((raw, heard) in words) {
            val w = norm(raw)
            if (!usable(w)) continue
            val exp = heard - stamp
            for (x in lw) if (x.w == w && abs(x.t - exp) <= window) offs.add((heard - x.t) to w)
        }
        if (offs.size < need) return null
        var best = emptyList<Pair<Long, String>>()
        for ((o, _) in offs) { val c = offs.filter { abs(it.first - o) <= 300 }; if (c.size > best.size) best = c }
        if (best.size < need || best.map { it.second }.toSet().size < 3) return null
        val mean = best.map { it.first }.average().toLong()
        // chorus repeats can look identical: refuse if a rival cluster is nearly as strong
        var rival = 0
        for ((o, _) in offs) if (abs(o - mean) > 1500) rival = maxOf(rival, offs.count { abs(it.first - o) <= 300 })
        if (rival * 10 >= best.size * 8) return null
        return Fit(mean, best.size)
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetter() || it == '\'' }
}
