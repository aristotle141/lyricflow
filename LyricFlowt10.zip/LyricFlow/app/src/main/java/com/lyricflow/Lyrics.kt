package com.lyricflow

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Wd(val ms: Long, val dur: Long, val text: String)
data class Line(val ms: Long, val text: String, val words: List<Wd>? = null)

/** (word, start, end) for every word in a line: real timings if the source has them, otherwise estimated. */
fun wordTimes(l: Line, nextMs: Long): List<Triple<String, Long, Long>> {
    l.words?.let { w -> if (w.isNotEmpty()) return w.map { Triple(it.text, it.ms, it.ms + it.dur) } }
    val ws = l.text.split(" ").filter { it.isNotBlank() }
    if (ws.isEmpty()) return emptyList()
    val end = minOf(nextMs, l.ms + (l.text.length * 90L).coerceAtLeast(1500))
    val total = ws.sumOf { it.length + 1 }
    var acc = 0
    return ws.map { w ->
        val a = l.ms + (end - l.ms) * acc / total
        acc += w.length + 1
        Triple(w, a, l.ms + (end - l.ms) * acc / total)
    }
}

class Fetched(val lines: List<Line>, val source: String)

object Lyrics {
    /** Word-synced LyricsPlus first, LRCLIB as the fallback. */
    suspend fun fetch(title: String, artist: String, album: String, durMs: Long): Fetched {
        val p = LyricsPlus.fetch(title, artist, album, durMs)
        if (p.isNotEmpty()) return Fetched(p, if (p.any { it.words != null }) "Word-synced · LyricsPlus" else "Line-synced · LyricsPlus")
        return Fetched(Lrclib.fetch(title, artist, durMs), "Line-synced · LRCLIB")
    }
}

object LyricsPlus {
    suspend fun fetch(title: String, artist: String, album: String, durMs: Long): List<Line> = withContext(Dispatchers.IO) {
        try {
            fun e(s: String) = URLEncoder.encode(s, "UTF-8")
            val q = "title=${e(title)}&artist=${e(artist)}" + (if (album.isNotBlank()) "&album=${e(album)}" else "") +
                (if (durMs > 0) "&duration=${durMs / 1000}" else "")
            val c = URL("https://lyricsplus.binimum.org/v2/lyrics/get?$q").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 7000
            c.setRequestProperty("User-Agent", "LyricFlow/1.0")
            val root = org.json.JSONObject(c.inputStream.bufferedReader().readText())
            val arr = root.optJSONArray("lyrics") ?: return@withContext emptyList()
            val wordType = root.optString("type") == "Word"
            val out = ArrayList<Line>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optLong("time", -1L)
                if (t < 0) continue
                val words = ArrayList<Wd>()
                val syl = o.optJSONArray("syllabus")
                if (wordType && syl != null) {
                    val cur = StringBuilder(); var start = 0L; var end = 0L
                    fun flush() { val w = cur.toString().trim(); if (w.isNotEmpty()) words.add(Wd(start, end - start, w)); cur.setLength(0) }
                    for (j in 0 until syl.length()) {
                        val s = syl.getJSONObject(j)
                        if (s.optBoolean("isBackground", false)) continue
                        val st = s.optLong("time", -1L)
                        if (st < 0) continue
                        val txt = s.optString("text", "")
                        if (cur.isEmpty()) start = st
                        cur.append(txt); end = st + s.optLong("duration", 0L)
                        if (txt.endsWith(" ")) flush()
                    }
                    flush()
                }
                val text = if (words.isNotEmpty()) words.joinToString(" ") { it.text } else o.optString("text", "").trim()
                out.add(Line(t, text, words.takeIf { it.isNotEmpty() }))
            }
            if (out.size >= 3 && !(out.last().ms < 2000 && out.size > 5)) out else emptyList()
        } catch (e: Exception) { emptyList() }
    }
}

object Lrclib {
    private val cache = HashMap<String, List<Line>>()

    /** Free synced lyrics from LRCLIB. Picks the version whose length best matches the song. */
    suspend fun fetch(title: String, artist: String, durMs: Long): List<Line> = withContext(Dispatchers.IO) {
        val key = "$artist|$title|${durMs / 3000}"
        cache[key]?.let { return@withContext it }
        try {
            val q = "track_name=${enc(title)}&artist_name=${enc(artist)}"
            val c = URL("https://lrclib.net/api/search?$q").openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "LyricFlow/1.0")
            val arr = JSONArray(c.inputStream.bufferedReader().readText())
            var best: String? = null
            var bestD = Double.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = o.optString("syncedLyrics", "")
                if (s.isBlank() || s == "null") continue
                val d = if (durMs > 0) Math.abs(o.optDouble("duration", 0.0) * 1000 - durMs) else 0.0
                if (d < bestD) { bestD = d; best = s }
            }
            val out = best?.let { parse(it) } ?: emptyList()
            if (out.isNotEmpty()) cache[key] = out
            out
        } catch (e: Exception) { emptyList() }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private val rx = Regex("""\[(\d+):(\d+(?:\.\d+)?)](.*)""")
    private fun parse(lrc: String) = lrc.lines().mapNotNull {
        rx.matchEntire(it.trim())?.let { m ->
            Line(((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong(), m.groupValues[3].trim())
        }
    }
}

object Translator {
    suspend fun translate(lines: List<Line>): List<String>? {
        val sample = lines.map { it.text }.filter { it.length > 3 }.take(8).joinToString(" ")
        if (sample.isBlank()) return null
        val src = LanguageIdentification.getClient().identifyLanguage(sample).await()
        val dst = TranslateLanguage.fromLanguageTag(Locale.getDefault().language) ?: return null
        val from = TranslateLanguage.fromLanguageTag(src) ?: return null
        if (from == dst) return null
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(dst).build())
        t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        return lines.map { if (it.text.isBlank()) "" else t.translate(it.text).await() }
    }
}

data class Match(val title: String, val artist: String, val offsetMs: Long, val clipStart: Long, val durMs: Long, val art: android.graphics.Bitmap? = null,
                 val album: String = "", val meta: String = "")

object Recognizer {
    @Suppress("DEPRECATION")
    suspend fun listen(cacheDir: File, token: String, wantArt: Boolean = false): Match? = withContext(Dispatchers.IO) {
        val f = File(cacheDir, "clip.m4a")
        val r = android.media.MediaRecorder().apply {
            setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
            setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC)
            setOutputFile(f.path); prepare(); start()
        }
        val clipStart = android.os.SystemClock.elapsedRealtime()
        delay(8000); r.stop(); r.release()
        try {
            val b = "----lf${System.nanoTime()}"
            val c = URL("https://api.audd.io/").openConnection() as HttpURLConnection
            c.doOutput = true; c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.outputStream.use { o ->
                fun field(n: String, v: String) = o.write("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray())
                field("api_token", token); field("return", "spotify")
                o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"clip.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n".toByteArray())
                o.write(f.readBytes()); o.write("\r\n--$b--\r\n".toByteArray())
            }
            val res = org.json.JSONObject(c.inputStream.bufferedReader().readText()).optJSONObject("result")
            res?.let {
                val sp = it.optJSONObject("spotify")
                val art = if (!wantArt) null else try {
                    val u = sp?.optJSONObject("album")?.optJSONArray("images")?.optJSONObject(0)?.optString("url")
                    if (u.isNullOrBlank()) null else URL(u).openStream().use { s -> android.graphics.BitmapFactory.decodeStream(s) }
                } catch (e: Exception) { null }
                Match(it.getString("title"), it.getString("artist"), tc(it.optString("timecode", "0:00")), clipStart,
                    sp?.optLong("duration_ms", 0L) ?: 0L, art,
                    it.optString("album", ""),
                    listOf(it.optString("release_date", "").take(4), it.optString("label", "")).filter { x -> x.isNotBlank() }.joinToString(" · "))
            }
        } catch (e: Exception) { null }
    }

    private fun tc(s: String): Long =
        s.split(":").map { it.toLongOrNull() ?: 0L }.fold(0L) { a, b -> a * 60 + b } * 1000
}
