package com.lyricflow

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class Theme(val name: String, val top: Color, val bottom: Color, val text: Color)

val themes = listOf(
    Theme("Midnight", Color(0xFF1B1F3B), Color(0xFF0A0B14), Color.White),
    Theme("Sunset", Color(0xFFFF7E5F), Color(0xFF6A1B9A), Color.White),
    Theme("Forest", Color(0xFF2E7D32), Color(0xFF07140A), Color.White),
    Theme("Ocean", Color(0xFF0288D1), Color(0xFF021A2E), Color.White),
    Theme("AMOLED", Color.Black, Color.Black, Color.White),
    Theme("Paper", Color(0xFFFFF8E7), Color(0xFFEADFC6), Color(0xFF222222)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lf", MODE_PRIVATE)
        setContent {
            var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            var translate by remember { mutableStateOf(false) }
            var listening by remember { mutableStateOf(false) }
            var menu by remember { mutableStateOf(false) }
            var lines by remember { mutableStateOf(emptyList<Line>()) }
            var tr by remember { mutableStateOf<List<String>?>(null) }
            var pos by remember { mutableLongStateOf(0L) }
            var nudge by remember { mutableLongStateOf(0L) }
            var token by remember { mutableStateOf(prefs.getString("audd", "") ?: "") }
            var showToken by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf("") }
            var manual by remember { mutableStateOf<Track?>(null) }
            val spotify by Now.track.collectAsState()
            val track = manual ?: spotify
            val scope = rememberCoroutineScope()
            val th = themes[themeIdx]
            val enabled = NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName)

            val identify: () -> Unit = {
                if (token.isBlank()) { menu = true; showToken = true; status = "Paste your AudD token first" }
                else scope.launch {
                    listening = true; status = "Listening…"
                    val m = Recognizer.listen(cacheDir, token.trim())
                    listening = false
                    if (m == null) status = "Couldn't identify it. Move closer and try again."
                    else { manual = Track(m.title, m.artist, m.offsetMs, true, m.clipStart); nudge = 0; status = "Tap the line you're hearing to lock the sync" }
                }
            }
            val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) identify() }

            LaunchedEffect(track?.title, track?.artist) {
                lines = emptyList(); tr = null
                track?.let { lines = Lrclib.fetch(it.title, it.artist) }
            }
            LaunchedEffect(translate, lines) {
                tr = if (translate && lines.isNotEmpty()) runCatching { Translator.translate(lines) }.getOrNull() else null
            }
            LaunchedEffect(track) {
                while (true) {
                    track?.let { pos = if (it.playing) it.posMs + SystemClock.elapsedRealtime() - it.stamp else it.posMs }
                    delay(50)
                }
            }
            val p = pos + nudge
            val active = lines.indexOfLast { it.ms <= p }.coerceAtLeast(0)
            val list = rememberLazyListState()
            val offsetPx = with(LocalDensity.current) { 200.dp.roundToPx() }
            LaunchedEffect(active, lines) { if (lines.isNotEmpty()) list.animateScrollToItem(active, -offsetPx) }

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.top, th.bottom)))) {
                if (lines.isNotEmpty()) LazyColumn(
                    Modifier.fillMaxSize(), state = list,
                    contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 140.dp, bottom = 320.dp)
                ) {
                    itemsIndexed(lines) { i, l ->
                        val d = abs(i - active)
                        val blurR by animateDpAsState(if (i == active) 0.dp else (d * 1.5f).coerceAtMost(5f).dp, label = "b")
                        val sc by animateFloatAsState(if (i == active) 1f else 0.88f, label = "s")
                        val al by animateFloatAsState(if (i == active) 1f else if (d == 1) 0.5f else 0.3f, label = "al")
                        Column(
                            Modifier.fillMaxWidth()
                                .clickable(remember { MutableInteractionSource() }, null) { nudge = l.ms - pos; status = "" }
                                .graphicsLayer { scaleX = sc; scaleY = sc; alpha = al; transformOrigin = TransformOrigin(0f, 0.5f) }
                                .blur(blurR, BlurredEdgeTreatment.Unbounded)
                                .padding(vertical = 12.dp)
                        ) {
                            val txt = l.text.ifBlank { "♪" }
                            if (i == active) {
                                val next = lines.getOrNull(i + 1)?.ms ?: (l.ms + 4000)
                                ActiveLine(txt, l.ms, minOf(next, l.ms + (txt.length * 90L).coerceAtLeast(1500)), p, th)
                            } else Text(txt, color = th.text, fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
                            tr?.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { Text(it, color = th.text.copy(0.7f), fontSize = 16.sp) }
                        }
                    }
                } else Text(
                    if (track == null) "Tap ◉ to listen\nor play a song on Spotify" else "No synced lyrics for this song",
                    color = th.text.copy(0.5f), fontSize = 20.sp, modifier = Modifier.align(Alignment.Center).padding(32.dp))

                Box(Modifier.fillMaxWidth().height(110.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(th.top, Color.Transparent))))
                Box(Modifier.fillMaxWidth().height(160.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, th.bottom))))

                Row(Modifier.fillMaxWidth().align(Alignment.TopCenter).statusBarsPadding().padding(24.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(track?.title ?: "", color = th.text.copy(0.9f), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(if (status.isNotBlank()) status else track?.artist ?: "", color = th.text.copy(0.55f), fontSize = 13.sp, maxLines = 1)
                    }
                    Text("⋯", color = th.text, fontSize = 28.sp, modifier = Modifier.clickable { menu = !menu }.padding(8.dp))
                }

                Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (menu) {
                        if (showToken) OutlinedTextField(token, { token = it; prefs.edit().putString("audd", it).apply() },
                            label = { Text("AudD token") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            Chip("Theme: ${th.name}", th) { themeIdx = (themeIdx + 1) % themes.size; prefs.edit().putInt("theme", themeIdx).apply() }
                            Chip(if (translate) "Translate: on" else "Translate: off", th) { translate = !translate }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            Chip("−0.25s", th) { nudge -= 250 }
                            Chip("+0.25s", th) { nudge += 250 }
                            Chip("Token", th) { showToken = !showToken }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            if (manual != null) Chip("Follow Spotify", th) { manual = null; nudge = 0; status = "" }
                            if (!enabled) Chip("Allow Spotify access", th) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Box(Modifier.size(64.dp).background(th.text.copy(if (listening) 0.35f else 0.18f), CircleShape).clickable {
                        if (!listening) {
                            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) identify()
                            else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }, contentAlignment = Alignment.Center) { Text(if (listening) "…" else "◉", color = th.text, fontSize = 26.sp) }
                }
            }
        }
    }
}

/** Apple Music-style: each word fades in as it is sung. */
@Composable
fun ActiveLine(text: String, start: Long, end: Long, p: Long, th: Theme) {
    val words = text.split(" ").filter { it.isNotBlank() }
    val total = words.sumOf { it.length + 1 }.coerceAtLeast(1)
    var acc = 0
    val ann = buildAnnotatedString {
        words.forEachIndexed { i, w ->
            val a = start + (end - start) * acc / total
            acc += w.length + 1
            val b = start + (end - start) * acc / total
            val prog = if (b > a) ((p - a).toFloat() / (b - a)).coerceIn(0f, 1f) else if (p >= a) 1f else 0f
            withStyle(SpanStyle(color = th.text.copy(alpha = 0.4f + 0.6f * prog))) {
                append(w); if (i < words.lastIndex) append(" ")
            }
        }
    }
    Text(ann, fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Chip(label: String, th: Theme, onClick: () -> Unit) {
    Text(label, color = th.text, fontSize = 13.sp, modifier = Modifier
        .background(th.text.copy(0.15f), RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp))
}
