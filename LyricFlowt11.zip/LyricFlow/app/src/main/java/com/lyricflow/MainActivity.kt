package com.lyricflow

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

/** AudD's timecode points near the middle of the clip: shift the song start later by this much until the app has learned its own value. */
const val MIC_SHIFT = 3500L

class Theme(val name: String, val top: Color, val bottom: Color, val text: Color)

val themes = listOf(
    Theme("Auto", Color(0xFF2A2F55), Color(0xFF0A0B14), Color.White),
    Theme("Sunset", Color(0xFFFF7E5F), Color(0xFF6A1B9A), Color.White),
    Theme("Forest", Color(0xFF2E7D32), Color(0xFF07140A), Color.White),
    Theme("Ocean", Color(0xFF0288D1), Color(0xFF021A2E), Color.White),
    Theme("AMOLED", Color.Black, Color.Black, Color.White),
    Theme("Paper", Color(0xFFFFF8E7), Color(0xFFEADFC6), Color(0xFF222222)),
)

class MainActivity : ComponentActivity() {
    private lateinit var ear: LyricListener
    override fun onStop() { super.onStop(); ear.stop() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ear = LyricListener(this)
        val prefs = getSharedPreferences("lf", MODE_PRIVATE)
        setContent {
            var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            var translate by remember { mutableStateOf(false) }
            var listening by remember { mutableStateOf(false) }
            var menu by remember { mutableStateOf(false) }
            var lines by remember { mutableStateOf(emptyList<Line>()) }
            var source by remember { mutableStateOf("") }
            var tr by remember { mutableStateOf<List<String>?>(null) }
            var pos by remember { mutableLongStateOf(0L) }
            var nudge by remember { mutableLongStateOf(0L) }
            var token by remember { mutableStateOf(prefs.getString("audd", "") ?: "") }
            var showToken by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf("") }
            var manual by remember { mutableStateOf<Track?>(null) }
            var locked by remember { mutableStateOf(false) }
            var vocal by remember { mutableStateOf(prefs.getBoolean("vocal", true)) }
            var baseStamp by remember { mutableLongStateOf(0L) }
            var learnedOnce by remember { mutableStateOf(false) }
            val track = manual
            val scope = rememberCoroutineScope()

            val art: Bitmap? = track?.art
            val artColor = remember(art) { art?.let { Color(Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0)) } }
            val t0 = themes[themeIdx]
            val auto = t0.name == "Auto" && artColor != null
            val th = Theme(t0.name,
                if (auto) lerp(artColor!!, Color.Black, 0.35f) else t0.top,
                if (auto) lerp(artColor!!, Color.Black, 0.8f) else t0.bottom, t0.text)

            val aligner = remember(lines) { if (lines.isEmpty()) null else Aligner(lines) }
            val alignerNow by rememberUpdatedState(aligner)
            val manualNow by rememberUpdatedState(manual)
            val lockedNow by rememberUpdatedState(locked)
            val baseNow by rememberUpdatedState(baseStamp)
            val learnedNow by rememberUpdatedState(learnedOnce)
            val learn: (Long) -> Unit = { d ->
                if (abs(d) <= 9000L) {
                    val l = ((prefs.getString("deltas", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.takeLast(8) + d)
                    prefs.edit().putString("deltas", l.joinToString(",")).putLong("learned", l.sorted()[l.size / 2]).apply()
                }
            }
            DisposableEffect(Unit) {
                ear.onWords = { words ->
                    val mm = manualNow
                    if (mm != null) {
                        val fit = alignerNow?.estimate(words, mm.stamp, if (lockedNow) 1200L else 2000L, if (lockedNow) 4 else 6)
                        if (fit != null && abs(fit.stamp - baseNow - prefs.getLong("learned", MIC_SHIFT)) <= 2000L) {
                            if (!lockedNow && !learnedNow && fit.votes >= 8) { learn(fit.stamp - baseNow); learnedOnce = true }
                            val ns = if (lockedNow) mm.stamp + (fit.stamp - mm.stamp).coerceIn(-400L, 400L) else fit.stamp
                            manual = mm.copy(stamp = ns)
                            nudge = 0; locked = true
                            status = "Locked on (${fit.votes} matches, shift " + String.format("%+.1fs", (fit.stamp - baseNow) / 1000.0) + ")"
                        } else if (!lockedNow) status = "Hearing: " + words.takeLast(6).joinToString(" ") { it.first }
                    }
                }
                onDispose { ear.onWords = {} }
            }

            val identify: () -> Unit = {
                if (token.isBlank()) { menu = true; showToken = true; status = "Paste your AudD token first" }
                else scope.launch {
                    ear.stop(); locked = false; listening = true; status = "Listening…"
                    val first = Recognizer.listen(cacheDir, token.trim(), true)
                    listening = false
                    if (first == null) status = "Couldn't identify it. Move closer and try again."
                    else {
                        baseStamp = first.clipStart - first.offsetMs - 500; learnedOnce = false
                        manual = Track(first.title, first.artist, 0L, true, baseStamp + prefs.getLong("learned", MIC_SHIFT),
                            first.durMs, first.art, first.album, first.meta)
                        nudge = 0
                        status = "Setting up vocal sync (first time downloads ~40 MB)…"
                        val model = if (vocal) ear.ensureModel() else null
                        if (!vocal) status = "Tap the line you're hearing to sync"
                        else if (model == null) status = "Vocal sync unavailable. Tap the line you're hearing to sync."
                        else { ear.start(model); status = "Listening to the vocals…" }
                    }
                }
            }
            val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) identify() }

            LaunchedEffect(track?.title, track?.artist, track?.durMs) {
                lines = emptyList(); tr = null; source = ""
                track?.let { val f = Lyrics.fetch(it.title, it.artist, it.album, it.durMs); lines = f.lines; if (f.lines.isNotEmpty()) source = f.source }
            }
            LaunchedEffect(translate, lines) {
                tr = if (translate && lines.isNotEmpty()) runCatching { Translator.translate(lines) }.getOrNull() else null
            }
            LaunchedEffect(track) {
                val t = track ?: return@LaunchedEffect
                while (true) {
                    withFrameMillis { pos = if (t.playing) t.posMs + SystemClock.elapsedRealtime() - t.stamp else t.posMs }
                }
            }
            val active by remember { derivedStateOf { val q = pos + nudge; lines.indexOfLast { it.ms <= q }.coerceAtLeast(0) } }
            val act = active
            val list = rememberLazyListState()
            val offsetPx = with(LocalDensity.current) { 200.dp.roundToPx() }
            LaunchedEffect(act, lines) { if (lines.isNotEmpty()) list.animateScrollToItem(act, -offsetPx) }

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.top, th.bottom)))) {
                if (lines.isNotEmpty()) LazyColumn(
                    Modifier.fillMaxSize(), state = list,
                    contentPadding = PaddingValues(start = 26.dp, end = 26.dp, top = 230.dp, bottom = 360.dp)
                ) {
                    itemsIndexed(lines) { i, l ->
                        val d = abs(i - act)
                        val sc by animateFloatAsState(if (d == 0) 1f else 0.9f, tween(450), label = "s")
                        val al by animateFloatAsState(if (d == 0) 1f else if (d == 1) 0.55f else 0.35f, tween(450), label = "a")
                        val bl by animateFloatAsState(if (d == 0) 0f else minOf(d, 4) * 3f, tween(450), label = "b")
                        Column(
                            Modifier.fillMaxWidth()
                                .clickable(remember { MutableInteractionSource() }, null) {
                                    nudge = l.ms - pos
                                    manual?.let { learn(it.stamp - nudge - baseStamp) }
                                    status = "Sync saved: " + String.format("%+.1fs", nudge / 1000.0)
                                }
                                .graphicsLayer {
                                    scaleX = sc; scaleY = sc; alpha = al
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                    if (Build.VERSION.SDK_INT >= 31 && bl > 0.5f) renderEffect = BlurEffect(bl, bl, TileMode.Decal)
                                }
                                .padding(vertical = 14.dp)
                        ) {
                            val txt = l.text.ifBlank { "♪" }
                            if (d == 0) ActiveLine(l.copy(text = txt), lines.getOrNull(i + 1)?.ms ?: (l.ms + 4000), { pos + nudge }, th)
                            else Text(txt, color = th.text, fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Bold)
                            tr?.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { Text(it, color = th.text.copy(0.7f), fontSize = 16.sp) }
                        }
                    }
                } else Text(
                    if (track == null) "Tap ◉ to identify the song\nplaying around you" else "No synced lyrics for this song",
                    color = th.text.copy(0.5f), fontSize = 20.sp, modifier = Modifier.align(Alignment.Center).padding(32.dp))

                Box(Modifier.fillMaxWidth().height(250.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(th.top, th.top, Color.Transparent))))
                Box(Modifier.fillMaxWidth().height(170.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, th.bottom))))

                Column(Modifier.fillMaxWidth().align(Alignment.TopCenter).statusBarsPadding().padding(24.dp, 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        art?.let { b -> Image(remember(b) { b.asImageBitmap() }, null, Modifier.size(68.dp).clip(RoundedCornerShape(12.dp))); Spacer(Modifier.width(14.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text(track?.title ?: "LyricFlow", color = th.text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            if (track != null) Text(track.artist, color = th.text.copy(0.75f), fontSize = 15.sp, maxLines = 1)
                            val sub = listOf(track?.album ?: "", track?.meta ?: "").filter { it.isNotBlank() }.joinToString(" · ")
                            if (sub.isNotBlank()) Text(sub, color = th.text.copy(0.5f), fontSize = 12.sp, maxLines = 1)
                        }
                        Text("⋯", color = th.text, fontSize = 28.sp, modifier = Modifier.clickable { menu = !menu }.padding(8.dp))
                    }
                    if (track != null && track.durMs > 0) ProgressBar({ pos + nudge }, track.durMs, th)
                    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (source.isNotBlank()) Pill(source, th)
                        if (status.isNotBlank()) Pill(status, th, Modifier.weight(1f, false))
                    }
                }

                Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (menu) {
                        if (showToken) OutlinedTextField(token, { token = it; prefs.edit().putString("audd", it).apply() },
                            label = { Text("AudD token") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Theme: ${th.name}", th) { themeIdx = (themeIdx + 1) % themes.size; prefs.edit().putInt("theme", themeIdx).apply() }
                            Chip(if (translate) "Translate: on" else "Translate: off", th) { translate = !translate }
                        }
                        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("−0.25s", th) { nudge -= 250 }
                            Chip("+0.25s", th) { nudge += 250 }
                            Chip("Reset sync", th) { nudge = 0; prefs.edit().remove("learned").remove("deltas").apply() }
                            Chip("Token", th) { showToken = !showToken }
                        }
                        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(if (vocal) "Vocal sync: on" else "Vocal sync: off", th) { vocal = !vocal; prefs.edit().putBoolean("vocal", vocal).apply(); if (!vocal) ear.stop() }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Box(Modifier.size(58.dp).background(th.text.copy(if (listening) 0.35f else 0.18f), CircleShape).clickable {
                        if (!listening) {
                            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) identify()
                            else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }, contentAlignment = Alignment.Center) { Text(if (listening) "…" else "◉", color = th.text, fontSize = 24.sp) }
                }
            }
        }
    }
}

/** Words fade in as they are sung, using real word timings when the lyrics source has them. */
@Composable
fun ActiveLine(l: Line, nextMs: Long, clock: () -> Long, th: Theme) {
    val p = clock()
    val ws = wordTimes(l, nextMs)
    val ann = buildAnnotatedString {
        ws.forEachIndexed { i, (w, a, b) ->
            val prog = if (b > a) ((p - a).toFloat() / (b - a)).coerceIn(0f, 1f) else if (p >= a) 1f else 0f
            withStyle(SpanStyle(color = th.text.copy(alpha = 0.4f + 0.6f * prog))) {
                append(w); if (i < ws.lastIndex) append(" ")
            }
        }
    }
    Text(ann, fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun ProgressBar(clock: () -> Long, dur: Long, th: Theme) {
    val p = clock().coerceIn(0L, dur)
    fun fmt(ms: Long) = String.format("%d:%02d", ms / 60000, (ms / 1000) % 60)
    Column(Modifier.padding(top = 12.dp)) {
        Box(Modifier.fillMaxWidth().height(4.dp).background(th.text.copy(0.2f), CircleShape)) {
            Box(Modifier.fillMaxWidth(p.toFloat() / dur).fillMaxHeight().background(th.text.copy(0.85f), CircleShape))
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(p), color = th.text.copy(0.5f), fontSize = 11.sp)
            Text("-" + fmt(dur - p), color = th.text.copy(0.5f), fontSize = 11.sp)
        }
    }
}

@Composable
fun Pill(label: String, th: Theme, modifier: Modifier = Modifier) {
    Text(label, color = th.text.copy(0.85f), fontSize = 12.sp, maxLines = 1,
        modifier = modifier.background(th.text.copy(0.12f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp))
}

@Composable
fun Chip(label: String, th: Theme, onClick: () -> Unit) {
    Text(label, color = th.text, fontSize = 13.sp, modifier = Modifier
        .background(th.text.copy(0.15f), RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp))
}
