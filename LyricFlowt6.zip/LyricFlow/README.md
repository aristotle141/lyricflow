# LyricFlow
Free SongSense-style app: Spotify now-playing -> synced lyrics (LRCLIB) -> optional on-device translation -> 6 themes. Mic "Identify" fallback via AudD.

Build: open this folder in Android Studio (Ladybug or newer), let Gradle sync, press Run (or Build > Build APK).
First launch: tap the banner and enable LyricFlow under Notification access.
Mic fallback: get a free token at audd.io and paste it into Recognizer.AUDD_TOKEN in Lyrics.kt.
Note: Spotify may need Settings > Device Broadcast Status enabled for some devices; the media-session path normally works without it.
