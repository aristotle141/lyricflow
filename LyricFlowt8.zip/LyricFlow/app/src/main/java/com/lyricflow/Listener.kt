package com.lyricflow

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.math.abs

/** Free on-device speech recognition (Vosk). Hears the vocals and reports each word with the time it was heard. */
class LyricListener(private val ctx: Context) {
    var onWords: (List<Pair<String, Long>>) -> Unit = {}
    private var model: Model? = null
    private var svc: SpeechService? = null
    private val name = "vosk-model-small-en-us-0.15"

    suspend fun ensureModel(): Model? = withContext(Dispatchers.IO) {
        model?.let { return@withContext it }
        val dir = File(ctx.filesDir, name)
        val done = File(dir, ".done")
        try {
            if (!done.exists()) {
                val root = ctx.filesDir.canonicalPath
                ZipInputStream(URL("https://alphacephei.com/vosk/models/$name.zip").openStream().buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val f = File(ctx.filesDir, e.name)
                        if (f.canonicalPath.startsWith(root)) {
                            if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                        }
                        e = z.nextEntry
                    }
                }
                done.writeText("ok")
            }
            Model(dir.path).also { model = it }
        } catch (e: Exception) { null }
    }

    fun start(m: Model) {
        stop()
        try {
            val rec = org.vosk.Recognizer(m, 16000.0f)
            rec.setWords(true)
            val s = SpeechService(rec, 16000.0f)
            val t0 = SystemClock.elapsedRealtime()
            s.startListening(object : RecognitionListener {
                override fun onResult(h: String?) = handle(h, t0)
                override fun onFinalResult(h: String?) = handle(h, t0)
                override fun onPartialResult(h: String?) {}
                override fun onError(e: Exception?) {}
                override fun onTimeout() {}
            })
            svc = s
        } catch (e: Exception) { svc = null }
    }

    fun stop() { svc?.stop(); svc?.shutdown(); svc = null }

    private fun handle(h: String?, t0: Long) {
        val arr = try { JSONObject(h ?: return).optJSONArray("result") } catch (e: Exception) { null } ?: return
        val out = ArrayList<Pair<String, Long>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(o.getString("word") to t0 + (o.getDouble("start") * 1000).toLong())
        }
        if (out.isNotEmpty()) onWords(out)
    }
}

/** Matches heard words to lyric words; every match votes for when the song started. The biggest cluster of votes wins. */
class Aligner(lines: List<Line>) {
    private class W(val w: String, val t: Long)
    private val lw: List<W>

    init {
        val out = ArrayList<W>()
        for ((i, l) in lines.withIndex()) {
            val words = l.text.split(" ").map { norm(it) }.filter { it.isNotEmpty() }
            if (words.isEmpty()) continue
            val end = minOf(lines.getOrNull(i + 1)?.ms ?: (l.ms + 4000), l.ms + (l.text.length * 90L).coerceAtLeast(1500))
            val total = words.sumOf { it.length + 1 }
            var acc = 0
            for (w in words) { out.add(W(w, l.ms + (end - l.ms) * acc / total)); acc += w.length + 1 }
        }
        lw = out
    }

    /** Returns the phone-clock time at which song time 0 happened, or null if not enough words matched. */
    fun estimate(words: List<Pair<String, Long>>, stamp: Long, window: Long): Long? {
        val offs = ArrayList<Long>()
        for ((raw, heard) in words) {
            val w = norm(raw)
            if (w.length < 2) continue
            val exp = heard - stamp
            for (x in lw) if (x.w == w && abs(x.t - exp) <= window) offs.add(heard - x.t)
        }
        if (offs.size < 3) return null
        var best = emptyList<Long>()
        for (o in offs) { val c = offs.filter { abs(it - o) <= 400 }; if (c.size > best.size) best = c }
        return if (best.size >= 3) best.average().toLong() else null
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetter() || it == '\'' }
}
