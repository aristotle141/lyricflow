package com.lyricflow

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Line(val ms: Long, val text: String)

object Lrclib {
    private val cache = HashMap<String, List<Line>>()

    /** Free synced lyrics from LRCLIB (no key needed). */
    suspend fun fetch(title: String, artist: String): List<Line> = withContext(Dispatchers.IO) {
        cache.getOrPut("$artist|$title") {
            try {
                val q = "track_name=${enc(title)}&artist_name=${enc(artist)}"
                val c = URL("https://lrclib.net/api/search?$q").openConnection() as HttpURLConnection
                c.setRequestProperty("User-Agent", "LyricFlow/1.0")
                val arr = JSONArray(c.inputStream.bufferedReader().readText())
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i).optString("syncedLyrics", "")
                    if (s.isNotBlank() && s != "null") return@getOrPut parse(s)
                }
                emptyList()
            } catch (e: Exception) { emptyList() }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private val rx = Regex("""\[(\d+):(\d+(?:\.\d+)?)](.*)""")
    private fun parse(lrc: String) = lrc.lines().mapNotNull {
        rx.matchEntire(it.trim())?.let { m ->
            Line(((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong(), m.groupValues[3].trim())
        }
    }
}

object Translator {
    /** Free on-device translation (ML Kit). Returns null if not needed or not possible. */
    suspend fun translate(lines: List<Line>): List<String>? {
        val sample = lines.map { it.text }.filter { it.length > 3 }.take(8).joinToString(" ")
        if (sample.isBlank()) return null
        val src = LanguageIdentification.getClient().identifyLanguage(sample).await()
        val dst = TranslateLanguage.fromLanguageTag(Locale.getDefault().language) ?: return null
        val from = TranslateLanguage.fromLanguageTag(src) ?: return null
        if (from == dst) return null
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(dst).build())
        t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        return lines.map { if (it.text.isBlank()) "" else t.translate(it.text).await() }
    }
}

data class Match(val title: String, val artist: String, val offsetMs: Long, val clipStart: Long)

object Recognizer {
    /** Records 8s from the mic, asks AudD what song it is and where in the song the clip matched. */
    @Suppress("DEPRECATION")
    suspend fun listen(cacheDir: File, token: String): Match? = withContext(Dispatchers.IO) {
        val f = File(cacheDir, "clip.m4a")
        val r = android.media.MediaRecorder().apply {
            setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
            setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC)
            setOutputFile(f.path); prepare(); start()
        }
        val clipStart = android.os.SystemClock.elapsedRealtime()
        delay(8000); r.stop(); r.release()
        try {
            val b = "----lf${System.nanoTime()}"
            val c = URL("https://api.audd.io/").openConnection() as HttpURLConnection
            c.doOutput = true; c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.outputStream.use { o ->
                o.write("--$b\r\nContent-Disposition: form-data; name=\"api_token\"\r\n\r\n$token\r\n".toByteArray())
                o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"clip.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n".toByteArray())
                o.write(f.readBytes()); o.write("\r\n--$b--\r\n".toByteArray())
            }
            val res = org.json.JSONObject(c.inputStream.bufferedReader().readText()).optJSONObject("result")
            res?.let { Match(it.getString("title"), it.getString("artist"), tc(it.optString("timecode", "0:00")), clipStart) }
        } catch (e: Exception) { null }
    }

    private fun tc(s: String): Long =
        s.split(":").map { it.toLongOrNull() ?: 0L }.fold(0L) { a, b -> a * 60 + b } * 1000
}
