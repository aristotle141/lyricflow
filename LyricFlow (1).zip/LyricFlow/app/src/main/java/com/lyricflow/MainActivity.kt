package com.lyricflow

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Theme(val name: String, val top: Color, val bottom: Color, val text: Color)

val themes = listOf(
    Theme("Midnight", Color(0xFF1B1F3B), Color(0xFF0A0B14), Color.White),
    Theme("Sunset", Color(0xFFFF7E5F), Color(0xFF6A1B9A), Color.White),
    Theme("Forest", Color(0xFF2E7D32), Color(0xFF07140A), Color.White),
    Theme("Ocean", Color(0xFF0288D1), Color(0xFF021A2E), Color.White),
    Theme("AMOLED", Color.Black, Color.Black, Color.White),
    Theme("Paper", Color(0xFFFFF8E7), Color(0xFFEADFC6), Color(0xFF222222)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lf", MODE_PRIVATE)
        setContent {
            var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            var translate by remember { mutableStateOf(false) }
            var listening by remember { mutableStateOf(false) }
            var lines by remember { mutableStateOf(emptyList<Line>()) }
            var tr by remember { mutableStateOf<List<String>?>(null) }
            var pos by remember { mutableLongStateOf(0L) }
            var nudge by remember { mutableLongStateOf(0L) }
            var token by remember { mutableStateOf(prefs.getString("audd", "") ?: "") }
            var showToken by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf("") }
            var manual by remember { mutableStateOf<Track?>(null) }
            val spotify by Now.track.collectAsState()
            val track = manual ?: spotify
            val scope = rememberCoroutineScope()
            val th = themes[themeIdx]
            val enabled = NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName)

            val identify: () -> Unit = {
                if (token.isBlank()) { showToken = true; status = "Paste your AudD token first" }
                else scope.launch {
                    listening = true; status = "Listening…"
                    val m = Recognizer.listen(cacheDir, token.trim())
                    listening = false
                    if (m == null) status = "Couldn't identify it. Move closer to the speaker and try again."
                    else { manual = Track(m.title, m.artist, m.offsetMs, true, m.clipStart); nudge = 0; status = "" }
                }
            }
            val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) identify() }

            LaunchedEffect(track?.title, track?.artist) {
                lines = emptyList(); tr = null
                track?.let { lines = Lrclib.fetch(it.title, it.artist) }
            }
            LaunchedEffect(translate, lines) {
                tr = if (translate && lines.isNotEmpty()) runCatching { Translator.translate(lines) }.getOrNull() else null
            }
            LaunchedEffect(track) {
                while (true) {
                    track?.let { pos = if (it.playing) it.posMs + SystemClock.elapsedRealtime() - it.stamp else it.posMs }
                    delay(80)
                }
            }
            val p = pos + nudge
            val active = lines.indexOfLast { it.ms <= p }.coerceAtLeast(0)
            val list = rememberLazyListState()
            LaunchedEffect(active) { if (lines.isNotEmpty()) list.animateScrollToItem(active, -300) }

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.top, th.bottom)))) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
                    Text(track?.title ?: "Nothing playing", color = th.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(track?.artist ?: "Tap Identify to listen, or play Spotify", color = th.text.copy(0.6f), fontSize = 14.sp)
                    if (status.isNotBlank()) Text(status, color = th.text, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                    if (showToken) OutlinedTextField(
                        value = token, onValueChange = { token = it; prefs.edit().putString("audd", it).apply() },
                        label = { Text("AudD token") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    Spacer(Modifier.height(8.dp))
                    when {
                        track == null && !enabled -> Text("Tap here to allow Spotify access (optional)", color = th.text, fontSize = 16.sp,
                            modifier = Modifier.clickable { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }.padding(vertical = 24.dp))
                        track != null && lines.isEmpty() -> Text("No synced lyrics found", color = th.text.copy(0.6f), modifier = Modifier.weight(1f).padding(24.dp))
                        else -> LazyColumn(Modifier.weight(1f), state = list) {
                            itemsIndexed(lines) { i, l ->
                                val a by animateFloatAsState(if (i == active) 1f else 0.35f, label = "a")
                                Column(Modifier.padding(vertical = 10.dp).alpha(a)) {
                                    if (i == active) ActiveLine(l.text.ifBlank { "♪" }, l.ms, lines.getOrNull(i + 1)?.ms ?: (l.ms + 4000), p, th)
                                    else Text(l.text.ifBlank { "♪" }, color = th.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    tr?.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { Text(it, color = th.text.copy(0.7f), fontSize = 16.sp) }
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        Chip("Theme: ${th.name}", th) { themeIdx = (themeIdx + 1) % themes.size; prefs.edit().putInt("theme", themeIdx).apply() }
                        Chip(if (translate) "Translate: on" else "Translate: off", th) { translate = !translate }
                        Chip(if (listening) "Listening…" else "Identify", th) {
                            if (!listening) {
                                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) identify()
                                else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        Chip("−0.5s", th) { nudge -= 500 }
                        Chip("+0.5s", th) { nudge += 500 }
                        Chip("Token", th) { showToken = !showToken }
                        if (manual != null) Chip("Spotify", th) { manual = null; nudge = 0 }
                    }
                }
            }
        }
    }
}

/** Karaoke-style: words light up in order across the line's duration. */
@Composable
fun ActiveLine(text: String, start: Long, end: Long, p: Long, th: Theme) {
    val words = text.split(" ").filter { it.isNotBlank() }
    val total = words.sumOf { it.length + 1 }.coerceAtLeast(1)
    var acc = 0
    val ann = buildAnnotatedString {
        words.forEachIndexed { i, w ->
            val wStart = start + (end - start) * acc / total
            acc += w.length + 1
            withStyle(SpanStyle(color = if (p >= wStart) th.text else th.text.copy(0.35f))) {
                append(w); if (i < words.lastIndex) append(" ")
            }
        }
    }
    Text(ann, fontSize = 30.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Chip(label: String, th: Theme, onClick: () -> Unit) {
    Text(label, color = th.text, fontSize = 13.sp, modifier = Modifier
        .background(th.text.copy(0.15f), RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp))
}
